"use client"

import { useRef } from "react"
import { motion, useInView } from "framer-motion"

const partners = [
  "Saudi Aramco",
  "SABIC",
  "NEOM",
  "Royal Commission",
  "Ministry of Transport",
  "Maaden",
  "STC",
  "ACWA Power",
  "Red Sea Global",
  "Roshn",
]

export default function Partners() {
  const sectionRef = useRef(null)
  const isInView = useInView(sectionRef, { once: true, margin: "-100px" })

  return (
    <section ref={sectionRef} className="relative py-24 bg-secondary border-y border-border overflow-hidden">
      <div className="mx-auto max-w-7xl px-6 lg:px-8 mb-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center"
        >
          <span className="text-xs font-semibold tracking-[0.3em] uppercase text-primary">
            Trusted By Industry Leaders
          </span>
        </motion.div>
      </div>

      {/* Marquee */}
      <div className="relative">
        <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-secondary to-transparent z-10" />
        <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-secondary to-transparent z-10" />

        <div className="flex animate-marquee">
          {[...partners, ...partners].map((partner, i) => (
            <div
              key={`${partner}-${i}`}
              className="flex-shrink-0 mx-12 flex items-center"
            >
              <div className="px-8 py-4 border border-border bg-background/50">
                <span className="text-lg font-bold text-muted-foreground whitespace-nowrap tracking-tight">
                  {partner}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
