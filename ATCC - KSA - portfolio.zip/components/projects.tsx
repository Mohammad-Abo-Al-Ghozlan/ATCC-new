"use client"

import { useRef, useState } from "react"
import { motion, useInView, AnimatePresence } from "framer-motion"
import { ArrowUpRight, X } from "lucide-react"

const projects = [
  {
    image: "/images/project-1.jpg",
    title: "Al Madinah Commercial Tower",
    category: "Steel Structure",
    description:
      "A 45-story commercial tower featuring advanced steel framework engineering, state-of-the-art curtain wall systems, and premium finishing throughout. This landmark project showcases our capabilities in high-rise construction and complex structural engineering.",
    specs: ["45 Floors", "120,000 sqm", "Steel Frame", "36 Months"],
  },
  {
    image: "/images/project-2.jpg",
    title: "King Fahd Highway Extension",
    category: "Infrastructure",
    description:
      "Major highway infrastructure expansion spanning 85km with bridges, overpasses, and modern drainage systems. Delivered on schedule using advanced asphalt and concrete technologies to international road standards.",
    specs: ["85 km", "12 Bridges", "Asphalt & Concrete", "24 Months"],
  },
  {
    image: "/images/project-3.jpg",
    title: "Jubail Industrial Complex",
    category: "Industrial",
    description:
      "Large-scale industrial facility featuring steel-framed warehousing, processing facilities, and administrative buildings. Complete MEP systems, fire safety installations, and specialized flooring solutions.",
    specs: ["250,000 sqm", "Phase I-III", "Full MEP", "48 Months"],
  },
  {
    image: "/images/project-4.jpg",
    title: "Riyadh Residential Compound",
    category: "Residential",
    description:
      "Premium gated residential development with 300+ luxury units, landscaped communal areas, underground parking, and complete infrastructure including roads, utilities, and recreational facilities.",
    specs: ["300+ Units", "Premium Finish", "Full Infrastructure", "30 Months"],
  },
]

export default function Projects() {
  const sectionRef = useRef(null)
  const isInView = useInView(sectionRef, { once: true, margin: "-100px" })
  const [selectedProject, setSelectedProject] = useState<number | null>(null)

  return (
    <>
      <section id="projects" ref={sectionRef} className="relative py-32 lg:py-40">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="mb-6"
          >
            <span className="text-xs font-semibold tracking-[0.3em] uppercase text-primary">
              Our Work
            </span>
            <div className="mt-2 h-px w-16 bg-primary" />
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="text-4xl lg:text-5xl font-extrabold tracking-tight text-foreground leading-tight mb-16 max-w-xl"
          >
            Featured
            <span className="text-primary"> Projects</span>
          </motion.h2>

          {/* Project Grid */}
          <div className="grid md:grid-cols-2 gap-6">
            {projects.map((project, i) => (
              <motion.button
                key={project.title}
                initial={{ opacity: 0, y: 40 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.15 + i * 0.1 }}
                onClick={() => setSelectedProject(i)}
                className="group relative overflow-hidden aspect-[4/3] text-left cursor-pointer"
              >
                <img
                  src={project.image}
                  alt={project.title}
                  className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-background/60 group-hover:bg-background/40 transition-colors duration-500" />

                <div className="relative z-10 h-full flex flex-col justify-end p-8">
                  <span className="text-xs font-semibold tracking-[0.2em] uppercase text-primary mb-3">
                    {project.category}
                  </span>
                  <h3 className="text-2xl lg:text-3xl font-bold text-foreground tracking-tight group-hover:text-primary transition-colors duration-300">
                    {project.title}
                  </h3>
                  <div className="mt-4 flex items-center gap-2 text-sm text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <span>View Details</span>
                    <ArrowUpRight className="h-4 w-4" />
                  </div>
                </div>
              </motion.button>
            ))}
          </div>
        </div>
      </section>

      {/* Project Modal */}
      <AnimatePresence>
        {selectedProject !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelectedProject(null)}
            className="fixed inset-0 z-[70] bg-background/90 backdrop-blur-sm flex items-center justify-center p-4 md:p-8"
          >
            <motion.div
              initial={{ opacity: 0, y: 30, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 30, scale: 0.95 }}
              transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
              onClick={(e) => e.stopPropagation()}
              className="relative w-full max-w-4xl max-h-[90vh] overflow-y-auto bg-card border border-border"
            >
              <button
                onClick={() => setSelectedProject(null)}
                className="absolute top-4 right-4 z-10 p-2 bg-background/80 text-foreground hover:text-primary transition-colors"
                aria-label="Close project details"
              >
                <X className="h-5 w-5" />
              </button>

              <div className="aspect-video relative">
                <img
                  src={projects[selectedProject].image}
                  alt={projects[selectedProject].title}
                  className="h-full w-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-card to-transparent" />
              </div>

              <div className="p-8 lg:p-12">
                <span className="text-xs font-semibold tracking-[0.2em] uppercase text-primary mb-3 block">
                  {projects[selectedProject].category}
                </span>
                <h3 className="text-3xl lg:text-4xl font-extrabold text-foreground tracking-tight mb-6">
                  {projects[selectedProject].title}
                </h3>
                <p className="text-muted-foreground leading-relaxed mb-8">
                  {projects[selectedProject].description}
                </p>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {projects[selectedProject].specs.map((spec) => (
                    <div key={spec} className="border border-border p-4 text-center">
                      <span className="text-sm font-semibold text-foreground">{spec}</span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
